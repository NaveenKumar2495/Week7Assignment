package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class MyHomePage extends ProjectSpecificMethod {
	
	public MyHomePage(ChromeDriver driver) {
		this.driver = driver ;
	}
	
	public MyAccountPage clickAccountTab() {
		driver.findElement(By.linkText("Accounts")).click() ;
		return new MyAccountPage(driver) ;
	}
	
	public MyHomePage verifyHomePageTitle() {
		String title = driver.getTitle() ;
		if(title.equals("My Home | opentaps CRM")) {
			System.out.println("Logged in successfully");
		}
		else {
			System.out.println("Log in was unsuccessful");	
		}
		return this ;
	}
	
	

}
