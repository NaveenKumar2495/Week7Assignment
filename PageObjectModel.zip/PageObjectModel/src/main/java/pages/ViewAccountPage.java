package pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class ViewAccountPage extends ProjectSpecificMethod {
	
	public ViewAccountPage(ChromeDriver driver) {
		this.driver = driver ;
	}
	
	public ViewAccountPage verifyAccountCreation() {
		String title = driver.getTitle() ;
		System.out.println(title);
		if (title.contentEquals("Account Details | opentaps CRM")) {
			System.out.println("Account got created successfully");
		}
		else{
			System.out.println("Account not created");
		}
		return this ;
	}
	
	public ViewAccountPage verifyAccountEdit() {
		String title = driver.getTitle() ;
		System.out.println(title);
		if (title.contentEquals("Account Details | opentaps CRM")) {
			System.out.println("Account got edited successfully");
		}
		else{
			System.out.println("Account not edited");
		}
		return this ;
	}
	
	public EditAccountPage clickEditButton() {
		driver.findElement(By.linkText("Edit") ).click() ;
		return new EditAccountPage(driver) ;
	}
	
	public DeleteAccountPage ClickDeleteButton() throws InterruptedException {
		driver.findElement(By.xpath("//a[@class ='subMenuButtonDangerous']") ).click() ;
		Alert alert = driver.switchTo().alert() ;
		alert.accept() ;
		Thread.sleep(4000) ;
		return new DeleteAccountPage(driver) ;
	}

}
