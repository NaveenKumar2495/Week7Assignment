package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class FindAccountPage extends ProjectSpecificMethod {
	
	public FindAccountPage(ChromeDriver driver) {
		this.driver = driver ;
	}
	
	public FindAccountPage enterAccoundId() {
		System.out.println("Account going to deleted"+AccountId);
		driver.findElement(By.name("id")).sendKeys(AccountId);
		return this ;
	}
	
	public FindAccountPage clickPhoneTab() {
		driver.findElement(By.xpath("//span[text()='Phone']")).click() ;
		return this ;
	}
	
	public FindAccountPage enterPhoneNumber(String phnum) {
		driver.findElement(By.name("phoneNumber")).sendKeys(phnum) ;
		return this ;
	}
	
	public FindAccountPage clickFindAccountButton() throws InterruptedException {
		driver.findElement(By.xpath("//button[text()='Find Accounts']")).click() ;
		Thread.sleep(5000)	;	
		return this ;
	}
	
	public FindAccountPage storeAccountId() {
		AccountId = driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).getText() ;
		System.out.println(AccountId);
		return this ;
	}
	
	public ViewAccountPage clickAccountId() {
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click() ;
		return new ViewAccountPage(driver) ;
	}
	
	public void verifyAccountAvailablity() {
		String msg = driver.findElement(By.xpath("//div[@class='x-paging-info']")).getText() ;
		System.out.println(msg);
		if(msg.equals("No records to display")) {
			System.out.println("Account id "+AccountId+" was not available");
		}			
		else {
		System.out.println("Account was available");
	}
		}
	

}
