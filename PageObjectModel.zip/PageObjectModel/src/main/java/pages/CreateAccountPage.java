package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import base.ProjectSpecificMethod;

public class CreateAccountPage extends ProjectSpecificMethod {
	
	public CreateAccountPage(ChromeDriver driver) {
		this.driver = driver ;
	}
	
	public CreateAccountPage enterAccountName(String accName) {
		driver.findElement(By.id("accountName")).sendKeys(accName)	;
		return this ;		
	}
	
	public CreateAccountPage enterNoOfEmp(String noOfEmp) {
		driver.findElement(By.id("numberEmployees")).sendKeys(noOfEmp)	;
		return this ;
	}
	
	public CreateAccountPage selectIndustry(String indus) {
		Select Industry = new Select(driver.findElement(By.name("industryEnumId"))) ;
		Industry.selectByVisibleText(indus) ;
		return this ;
	}
	
	public CreateAccountPage enterDescription(String descrip) {
		driver.findElement(By.name("description")).sendKeys(descrip)	;
		return this ;
	}
	
	public CreateAccountPage enterPhoneNum(String Phnum) {
		driver.findElement(By.id("primaryPhoneNumber")).sendKeys(Phnum)	;
		return this ;
	}
	
	public CreateAccountPage selectState(String state) {
		Select st = new Select(driver.findElement(By.id("generalStateProvinceGeoId"))) ;
		st.selectByVisibleText(state) ;
		return this ;		
	}
	
	public ViewAccountPage clickSaveButton() {
		driver.findElement(By.className("smallSubmit")).click();
		return new ViewAccountPage(driver) ;
	}

}
