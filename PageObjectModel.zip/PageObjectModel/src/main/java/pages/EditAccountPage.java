package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class EditAccountPage extends ProjectSpecificMethod {
	
	public EditAccountPage(ChromeDriver driver) {
		this.driver = driver ;
	}
	
	public EditAccountPage clearDescription() {
		driver.findElement(By.name("description")).clear()	;
		return this ;
	}
	
	public EditAccountPage enterImpNote(String impNote) {
		driver.findElement(By.name("importantNote")).sendKeys(impNote)	;
		return this ;
	}
	
	public ViewAccountPage clickEditSaveButton() {
		driver.findElement(By.className("smallSubmit")).click();
		return new ViewAccountPage(driver) ;
	}

}
