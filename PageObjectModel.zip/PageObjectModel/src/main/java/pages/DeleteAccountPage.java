package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class DeleteAccountPage extends ProjectSpecificMethod {
	
	public DeleteAccountPage(ChromeDriver driver) {
		this.driver = driver ;
	}
	
	public MyAccountPage verifyWarningMsg() {
		String warning = driver.findElement(By.xpath("//span[@class ='subSectionWarning']")).getText() ;
		if(warning.contains("This account was deactivated")) {
			System.out.println("Account got deleted successfully");
		}
		else {
			System.out.println("Account didn't get deleted");
		}
		return new MyAccountPage(driver) ;
	}
	

}
