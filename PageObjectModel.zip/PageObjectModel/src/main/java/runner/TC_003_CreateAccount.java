package runner;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC_003_CreateAccount extends ProjectSpecificMethod {

	@BeforeTest
	public void setValue() {
		data ="CreateAccount" ; 
	}
	
	@Test(dataProvider="getData")
	public void runCreateAccount(String uName, String password, String accName, String noOfEmp 
			, String indus, String description, String phoneNum, String state) {
		LoginPage ca = new LoginPage(driver) ;
		ca.enterUserName(uName).enterPassword(password)
		.clickLoginButton().clickCRMSFALink()
		.clickAccountTab().clickCreateAccount()
		.enterAccountName(accName).enterNoOfEmp(noOfEmp)
		.selectIndustry(indus).enterDescription(description)
		.enterPhoneNum(phoneNum).selectState(state)
		.clickSaveButton().verifyAccountCreation() ;		
	}
	
	
}
