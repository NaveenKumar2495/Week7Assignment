package runner;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC_002_LogoutPage extends ProjectSpecificMethod {
	
	@BeforeTest
	public void setValue() {
		data ="Login" ; 
	}
	
	@Test(dataProvider="getData")
	public void runLogoutPage(String uName, String password) {
		LoginPage lo = new LoginPage(driver) ;
		lo.enterUserName(uName).enterPassword(password)
		.clickLoginButton().clickLogoutButton() 
		.verifyLoginPageTitle() ;
		
	}
	
	

}
