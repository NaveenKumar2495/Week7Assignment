package runner;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC_005_DeleteAccount extends ProjectSpecificMethod {
	
	@BeforeTest
	public void setValue() {
		data ="DeleteAccount" ; 
	}
	
	@Test(dataProvider="getData")
	public void runDeleteAccount(String uName, String password, String phoneNum) throws InterruptedException {
		LoginPage da = new LoginPage(driver) ;
		da.enterUserName(uName).enterPassword(password)
		.clickLoginButton().clickCRMSFALink()
		.clickAccountTab().clickFindAccount()
		.clickPhoneTab().enterPhoneNumber(phoneNum)
		.clickFindAccountButton().storeAccountId()
		.clickAccountId().ClickDeleteButton()
		.verifyWarningMsg() ;
		
	}
	

}
