package runner;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC_004_EditAccount extends ProjectSpecificMethod {
	
	@BeforeTest
	public void setValue() {
		data ="EditAccount" ; 
	}
	
	@Test(dataProvider="getData")
	public void runEditAccount(String uName, String password, 
			String phoneNum , String impNote) throws InterruptedException {		
		LoginPage ea = new LoginPage(driver) ;
		ea.enterUserName(uName).enterPassword(password)
		.clickLoginButton().clickCRMSFALink()
		.clickAccountTab().clickFindAccount()
		.clickPhoneTab().enterPhoneNumber(phoneNum)
		.clickFindAccountButton().clickAccountId()
		.clickEditButton().clearDescription()
		.enterImpNote(impNote).clickEditSaveButton()
		.verifyAccountEdit() ;
			
	}

}
