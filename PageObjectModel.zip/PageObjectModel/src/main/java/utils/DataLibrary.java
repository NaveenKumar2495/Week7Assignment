package utils;

import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DataLibrary {
	
	public static String[][] readvalue(String FileName) throws IOException {
		
		XSSFWorkbook wb = new XSSFWorkbook("./data/"+FileName+".xlsx") ;
		XSSFSheet sheet = wb.getSheetAt(0)	;
		int rowCount = sheet.getLastRowNum();
		short cellCount = sheet.getRow(1).getLastCellNum() ;
		System.out.println("Total no of rows is "+rowCount);
		System.out.println("Total no of Column is "+cellCount);
		
		String[][] data = new String[rowCount][cellCount] ;
		for(int i=1 ; i<=rowCount ; i++) {
			for(int j=0 ; j<cellCount ; j++) {
					String excelSheetValue = sheet.getRow(i).getCell(j).getStringCellValue() ;
					data[i-1][j] = excelSheetValue ;
					System.out.println(data[i-1][j]);							
			}
		}
		wb.close() ;		
		return data ; 
	}
	
	
	

}
